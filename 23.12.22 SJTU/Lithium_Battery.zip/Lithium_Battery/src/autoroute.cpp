#include "autoroute.h"

void PlanA(void){
    ChassisAuto autobase;
    //PID setting
    autobase.Line.setCoefficient(0.01,0,2.5);
    autobase.Line.seterrorTol(0.5);
    autobase.Line.setIrange(0.01,1);

    autobase.Angle.setCoefficient(390,8.9,2230);
    autobase.Angle.set_variable_param(500,0.07);
    autobase.Angle.seterrorTol(0.3);
    autobase.Angle.setIrange(0.01,2000);

    autobase.VisionX.setCoefficient(390,8.9,2230);
    autobase.VisionX.set_variable_param(500,0.07);
    autobase.VisionX.seterrorTol(0.3);
    autobase.VisionX.setIrange(0.01,1000);

    autobase.VisionY.setCoefficient(0.01,0,2.5);
    autobase.VisionY.seterrorTol(0.5);
    autobase.VisionY.setIrange(0.01,1);

    thread take(auto_take);
    thread arm(auto_arm);
    thread shoot(auto_shoot);
    thread piston(auto_piston);

    //actions
    //......还没想好怎么写

}