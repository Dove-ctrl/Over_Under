#include "opfunction.h"
using namespace vex;

const int LeftDEADZONE = 5;
const int RightDEADZONE = 5;

void op_movement(){
    Chassis base;
    while(true){
        base.get_controller(127,127);
        //deadzone setting
        if(abs(Controller1.Axis3.position())<=LeftDEADZONE && abs(Controller1.Axis1.position())<=RightDEADZONE){
            base.motor_brake(brake);
        }else{
            base.chassis_movement();
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

void arm_control(){
    int bumperswitch;
    //determine the movement trend of the arm,if you press R1 means the channel of R1 is opening
    bool channelR1,channelR2;
    while(true){
        //separate two statuses of bumper to avoid the arm being stucked
        if(Lbumper.pressing()||Rbumper.pressing()){bumperswitch=1;}
        else{bumperswitch=0;}

        switch (bumperswitch)
        {
        case 0:
            if(Controller1.ButtonR1.pressing()){
                //if press R1,the arm move towards the direction that R1 controls,so the channelR1 is true
                ArmL.spin(fwd,MAXVOLTAGE,voltageUnits::mV);
                ArmR.spin(fwd,MAXVOLTAGE,voltageUnits::mV);
                channelR1=true,channelR2=false;
            }else if(Controller1.ButtonR2.pressing()){
                //if press R2,the arm move towards the direction that R2 controls,so the channelR2 is true
                ArmL.spin(reverse,MAXVOLTAGE,voltageUnits::mV);
                ArmR.spin(reverse,MAXVOLTAGE,voltageUnits::mV);
                channelR1=false,channelR2=true;
            }else{
                ArmL.stop(coast);
                ArmR.stop(coast);
            }
            break;
        case 1:
            if(channelR1){
                while(Lbumper.pressing()){
                    ArmL.spin(reverse,(Controller1.ButtonR2.pressing())*MAXVOLTAGE,voltageUnits::mV);
                    ArmR.spin(reverse,(Controller1.ButtonR2.pressing())*MAXVOLTAGE,voltageUnits::mV);
                }
                break;
            }else if(channelR2){
                while(Lbumper.pressing()){
                    ArmL.spin(fwd,(Controller1.ButtonR1.pressing())*MAXVOLTAGE,voltageUnits::mV);
                    ArmR.spin(fwd,(Controller1.ButtonR1.pressing())*MAXVOLTAGE,voltageUnits::mV);
                }
                break;
            }else{
                ArmL.spin(fwd,(Controller1.ButtonR1.pressing())*MAXVOLTAGE-
                (Controller1.ButtonR2.pressing())*MAXVOLTAGE,voltageUnits::mV);
                ArmR.spin(fwd,(Controller1.ButtonR1.pressing())*MAXVOLTAGE-
                (Controller1.ButtonR2.pressing())*MAXVOLTAGE,voltageUnits::mV);
            }
            break;
        default:
            break;
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

void takein_control(){
    while(true){
        if(Controller1.ButtonL1.pressing()){
            Takein.spin(fwd,MAXVOLTAGE,voltageUnits::mV);
        }else if(Controller1.ButtonL2.pressing()){
            Takein.spin(reverse,MAXVOLTAGE,voltageUnits::mV);
        }else{
            Takein.stop(brake);
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

void shoot_control(){
    Shoot.setVelocity(100,pct);
    while(true){
        if(Controller1.ButtonA.pressing()){
            Shoot.resetPosition();
            Shoot.spinTo(360,deg,true);
        }else{
            Shoot.stop(hold);
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

void piston_control(){
    while(true){
        if(Controller1.ButtonA.pressing()){
            piston1.set(true);
            piston2.set(true);
        }else if(Controller1.ButtonB.pressing()){
            piston1.set(false);
            piston2.set(false);
        }
        this_thread::sleep_for(UPDATETIME);
    }
}