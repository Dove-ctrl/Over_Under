#include "autofunction.h"
using namespace vex;

bool TAKEIN_SWITCH = false;
bool TAKEOUT_SWITCH = false;
bool ARMUP_SWITCH = false;
bool ARMDOWN_SWITCH = false;
bool SHOOT_SWITCH = false;
bool PISTON_SWITCH = false;

/// @brief Using liner velocity and angula rvelocity to control chassis.
/// @param base instantiation of ChassisAuto
/// @param status move type:left, right, stright, curve
/// @param LV liner velocity (pct)
/// @param AV angular velocity (pct)
/// @param yagon the yagon that be set by progarmmer
/// @param t when go stright,the time is used for keep moving,but when turn left or right,the time is used for stopping PID
void auto_movement(ChassisAuto base,movetype status,float LV,float AV,float yagon,float t){
    base.reset(base._ALLSENSOR);
    LV=(LV/100)*12700;AV=(AV/100)*12700;
    base.set_LinerVel_AngularVel(LV,AV);
    switch (status)
    {
    case LEFT:
        INERTIAL.setHeading(180,deg);
        yagon=180-yagon;
        base.Angle.setTarget(yagon);
        base.reset(ChassisAuto::sensor::_TIMER);
        while(!base.Angle.targetArrived()){
            base.Angle.update(INERTIAL.heading());
            base.get_revised_value(0,base.Angle.getoutput());
            base.chassis_movement();
            if(base.T.value()>=t){break;}
            wait(UPDATETIME,msec);
        }
        base.reset(ChassisAuto::sensor::_MOTOR);
        base.Angle.resetfirstTime();base.Angle.resetI();base.Angle.resetoutput();
        wait(150,msec);
        break;
    case RIGHT:
        INERTIAL.setHeading(180,deg);
        yagon=180+yagon;
        base.Angle.setTarget(yagon);
        base.reset(ChassisAuto::sensor::_TIMER);
        while(!base.Angle.targetArrived()){
            base.Angle.update(INERTIAL.heading());
            base.get_revised_value(0,base.Angle.getoutput());
            base.chassis_movement();
            if(base.T.value()>=t){break;}
            wait(UPDATETIME,msec);
        }
        base.reset(ChassisAuto::sensor::_MOTOR);
        base.Angle.resetfirstTime();base.Angle.resetI();base.Angle.resetoutput();
        wait(150,msec);
        break;
    case STRIGHT:
        yagon=yagon+180;
        INERTIAL.setHeading(180,deg);
        base.Line.setTarget(yagon);
        base.reset(ChassisAuto::sensor::_TIMER);
        while(t>=base.T.value()){
            base.Line.update(INERTIAL.heading());
            base.get_revised_value(0,base.Line.getoutput());
            base.chassis_movement();
            wait(UPDATETIME,msec);
        }
        base.reset(ChassisAuto::sensor::_MOTOR);
        base.Line.resetfirstTime();base.Line.resetI();base.Line.resetoutput();
        wait(150,msec);
        break;
    case CURVE:
        
        break;
    default:
        break;
    }
}

void auto_take(){
    while(true){
        if(TAKEIN_SWITCH){
            Takein.spin(fwd,MAXVOLTAGE,voltageUnits::mV);
        }else if(TAKEOUT_SWITCH){
            Takein.spin(reverse,MAXVOLTAGE,voltageUnits::mV);
        }else{
            Takein.stop();
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

void auto_arm(){
    double r=0;
    ArmL.setVelocity(100,pct);ArmR.setVelocity(100,pct);
    ArmL.resetPosition();ArmR.resetPosition();
    while(true){
        if(ARMUP_SWITCH){
            ArmL.spinToPosition(r,deg,false);
            ArmR.spinToPosition(r,deg,false);
        }else if(ARMDOWN_SWITCH){
            ArmL.spinToPosition(-r,deg,false);
            ArmR.spinToPosition(-r,deg,false);
        }else{
            ArmL.stop();ArmR.stop();
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

void auto_shoot(){
    Shoot.setVelocity(100,pct);
    double r=0;
    while(true){
        if(SHOOT_SWITCH){
            Shoot.resetPosition();
            Shoot.spinTo(r,deg,true);
        }else{
            Shoot.stop();
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

void auto_piston(){
    while(true){
        if(PISTON_SWITCH){
            piston1.set(true);piston2.set(true);
        }else{
            piston1.set(false);piston2.set(false);
        }
        this_thread::sleep_for(UPDATETIME);
    }
}

bool vision_tracking(ChassisAuto base,object sample,int targetX,int targetY,float t){
    timer T;T.clear();
    base.VisionX.setTarget(targetX);
    base.VisionY.setTarget(targetY);
    base.set_LinerVel_AngularVel(0,0);
    while(true){
        sample=get_triball(Vision__S_GREEN);
        base.VisionX.update(sample.centerX);
        base.VisionY.update(sample.centerY);

        base.get_revised_value(base.VisionY.getoutput(),base.VisionX.getoutput());
        base.chassis_movement();

        if((base.VisionX.targetArrived()&&base.VisionY.targetArrived())||T.value()>=t){
            base.VisionY.resetfirstTime();
            base.VisionY.resetI();
            base.VisionY.resetoutput();
            base.VisionX.resetfirstTime();
            base.VisionX.resetI();
            base.VisionX.resetoutput();
            return true;
            break;
        }
        return false;
        wait(UPDATETIME,msec);
    }
}