#include "vision.h"
using namespace vex;

object get_triball(signature sig){
    Vision.setSignature(sig);
    return Vision.largestObject;
}