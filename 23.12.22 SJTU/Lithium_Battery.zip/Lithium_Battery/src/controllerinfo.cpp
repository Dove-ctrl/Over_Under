#include "controllerinfo.h"
using namespace vex;

template<typename T>
void info_display(T info,int r,int c){
    Controller1.Screen.setCursor(r,c);
    Controller1.Screen.print(info);
}

template void info_display(int info,int r,int c);
template void info_display(double info,int r,int c);
template void info_display(const char *info,int r,int c);

void allclear(){
    Controller1.Screen.clearScreen();
}

void inertial_info(){
    double d;
    while (1){
        d=INERTIAL.heading();
        info_display(d,2,1);
        this_thread::sleep_for(10);
    }
}