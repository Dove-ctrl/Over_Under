#include "vex.h"
#include "chassis.h"
#include "opfunction.h"
#include "controllerinfo.h"
#include "autoroute.h"

using namespace vex;
competition Competition;

void pre_auton(void) {
  allclear();
  info_display("初始化ing......",1,1);
  info_display("保持机器静止不动",2,1);
  INERTIAL.calibrate();
  waitUntil(!INERTIAL.isCalibrating());
  allclear();
  info_display("初始化成功!",1,1);
  info_display("准备进入自动阶段......",2,1);
}

void autonomous(void) {
  allclear();
  info_display("正在执行自动程序......",1,1);
  if(Competition.isAutonomous()){
    PlanA();
    info_display("自动程序已结束",2,1);
  }else{
    thread::interruptAll();
  }
}

void usercontrol(void) {
  if(Competition.isDriverControl()){
    allclear();
    info_display("正在执行手动程序......",1,1);
    thread base(op_movement);
    thread arm(arm_control);
    thread takein(takein_control);
    thread shoot(shoot_control);
    thread piston(piston_control);
  }else{
    thread::interruptAll();
  }
}

int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  pre_auton();

  while (true) {
    wait(100, msec);
  }
}