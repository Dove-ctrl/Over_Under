#ifndef OPFUNCTION_H_
#define OPFUNCTION_H_
#include "vex.h"
#include "chassis.h"

void op_movement();
void arm_control();
void takein_control();
void shoot_control();
void piston_control();

#endif