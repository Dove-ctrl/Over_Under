#ifndef AUTOROUTE_H_
#define AUTOROUTE_H_

#include "vex.h"
#include "autofunction.h"
using namespace vex;

void PlanA(void);

#endif