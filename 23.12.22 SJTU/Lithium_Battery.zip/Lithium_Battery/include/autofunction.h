#ifndef AUTOFUNCTION_H_
#define AUTOFUNCTION_H_

#include "vex.h"
#include "chassis.h"
#include "PID.h"
#include "vision.h"
using namespace vex;

const enum movetype{
    STRIGHT,CURVE,LEFT,RIGHT
};

extern bool TAKEIN_SWITCH;
extern bool TAKEOUT_SWITCH;
extern bool ARMUP_SWITCH;
extern bool ARMDOWN_SWITCH;
extern bool SHOOT_SWITCH;
extern bool PISTON_SWITCH;

void auto_movement(ChassisAuto,movetype,float,float,float,float);
void auto_take();
void auto_shoot();
void auto_arm();
void auto_piston();
bool vision_tracking(ChassisAuto,object,int,int,float);

#endif