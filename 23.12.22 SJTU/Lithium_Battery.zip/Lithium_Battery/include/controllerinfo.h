#ifndef CONTROLLERINFO_H_
#define CONTROLLERINFO_H_
#include "vex.h"

template<typename T>
void info_display(T,int,int);
void allclear();

void inertial_info();

#endif